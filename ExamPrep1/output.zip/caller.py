import os
import django
from django.db.models import Q, Count

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from helpers import populate_model_with_data
from main_app.models import Actor, Movie, Director



def populate_db():

    populate_model_with_data(Director)
    populate_model_with_data(Actor)
    populate_model_with_data(Movie)


def get_directors(search_name=None, search_nationality=None):

    directors = None
    if search_name is not None and search_nationality is not None:
        directors = Director.objects.filter(
            Q(full_name__icontains=search_name) | Q(nationality__icontains=search_nationality))
    elif search_name is not None:
        directors = Director.objects.filter(
                    full_name__icontains=search_name)
    elif search_nationality is not None:
        directors = Director.objects.filter(
                    nationality__icontains=search_nationality)

    if directors is None:
        return ''

    return '\n'.join([
        f"Director: {d.full_name}, nationality: {d.nationality}, experience: {d.years_of_experience}"
        for d in directors.order_by('full_name')
    ])


def get_top_director():

    top_director = Director.objects.get_directors_by_movies_count().first()

    if top_director is None or top_director.movies_count == 0:
        return ''
    return f"Top Director: {top_director.full_name}, movies: {top_director.movies_count}."



def get_top_actor():

    top_actor = (Actor.objects.prefetch_related('starring_movie')
                 .annotate(movies_count=Count('starring_movie'))
                 .filter(movies_count__gt=0)
                 .order_by('-movies_count', 'full_name').first()
                 )

    if top_actor is not None:

        avg_rating = sum([m.rating for m in top_actor.starring_movie.all()]) / top_actor.movies_count
        return (f"Top Actor: {top_actor.full_name}, "
                f"starring in movies: {', '.join([m.title for m in top_actor.starring_movie.all()])}, "
                f"movies average rating: {avg_rating:.1f}")
    return ''












