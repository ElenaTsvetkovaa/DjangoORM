import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Lecturer, Subject, Student

# Keep the data from the previous exercise, so you can reuse it

from main_app.models import Student

# Keep the data from the previous exercises, so you can reuse it

student = Student.objects.last()

# for subj in student.subjects.all():
#     print(subj.name)

subject = Subject.objects.get(id=3)

for e in subject.studentenrollment_set.all():
    print(f"{e.student.first_name} {e.student.last_name}")
